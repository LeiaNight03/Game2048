# -*- codeing = utf-8 -*-
# @Time : 2021/12/8 8:48
# @Author : Group9
# @File : __init__.py
# @software : PyCharm

import pygame;

from main import main
from block import Block2048


# run the game
main();
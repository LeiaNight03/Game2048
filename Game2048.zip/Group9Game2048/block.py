# -*- codeing = utf-8 -*-
# @Time : 2021/11/4 9:35
# @Author : Group 9
# @File : block.py
# @software : PyCharm

import pygame.image

# create a class to contain the message of each block
# value : integer, to set the value of the block
# x : integer, the position of the image set in the screen
# y : integer, the position of the image set in the screen
# image : String, set the path of the picture used in the game
# isempty : boolean , to justify if the block is empty(equal to value == 0)
class Block2048:
    # the create function to create the block
    def __init__(self, value, x, y, surface):
        self.value = value
        self.x = x
        self.y = y
        self.isempty = True
        self.surface = surface
        self.image = "image/0.png"
        pass

    # create a new block, used to reset
    def createblock(self):
        self.value = 0
        self.isempty = True
        pass

    # this function is to update the image of the block by its value
    def imageupdate(self):
        location = "./image/0.png"
        if self.value == 0:
            location = "./image/0.png"
        elif self.value == 2:
            location = "./image/2.png"
        elif self.value == 4:
            location = "./image/4.png"
        elif self.value == 8:
            location = "./image/8.png"
        elif self.value == 16:
            location = "./image/16.png"
        elif self.value == 32:
            location = "./image/32.png"
        elif self.value == 64:
            location = "./image/64.png"
        elif self.value == 128:
            location = "./image/128.png"
        elif self.value == 256:
            location = "./image/256.png"
        elif self.value == 512:
            location = "./image/512.png"
        elif self.value == 1024:
            location = "./image/1024.png"
        elif self.value == 2048:
            location = "./image/2048.png"
        self.image = pygame.image.load(location)

        # replace the image by the new one
        rect = pygame.Rect(self.x,self.y,70,70)
        self.surface.blit(self.image, rect)
        pass

    # update the value and the relevant
    def blockupdate(self):
        if self.value == 0:
            self.isempty = True
        else:
            self.isempty = False
        self.imageupdate()



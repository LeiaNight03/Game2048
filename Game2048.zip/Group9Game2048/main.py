# -*- codeing = utf-8 -*-
# @Time : 2021/11/4 9:31
# @Author : Group 9
# @File : main.py
# @software : PyCharm
import sys
import tkinter
from tkinter import messagebox
from block import Block2048
import pygame

import gamefunction

# create a function to create a messagebox to show some message
def show_warning(msg):
    # create the new window
    top = tkinter.Tk()
    top.withdraw()
    top.update()
    print(msg)
    # use the messagebox tool to create a box to show the message
    messagebox.showwarning(" ", msg)
    # exit the box
    top.destroy()


# create the main function of the game, including the key listener and the initial of the game
def main():

    # initiate the pygame
    pygame.init()
    pygame.font.init()
    # game code

    # create the surface of the game
    screen = pygame.display.set_mode((400, 650))
    # set the title of the window
    pygame.display.set_caption("2048")

    # put the background of the game to the surface
    rectbackground = pygame.Rect(0,0,400,650)
    backimage = pygame.image.load("./image/background.png")
    screen.blit(backimage,rectbackground)

    # set the font and place the text to the game window
    fonts = pygame.font.get_default_font()
    myfont = pygame.font.Font(fonts, 32)
    text2048 = myfont.render("2048", True, (0, 0, 0))
    screen.blit(text2048, (150, 100))

    # initiate the 16 blocks by list and generate two blocks as the opening of the game
    block = gamefunction.initblock(screen)
    block = gamefunction.gengetatenewblock(block)
    block = gamefunction.gengetatenewblock(block)

    # update the window of the game
    for i in range(4):
        for j in range(4):
            block[i][j].blockupdate()

    pygame.display.update()

    # the loop used to running the game
    while True:
        # get the value and type of the listener
        for event in pygame.event.get():
            # print(event)
            # to justify if the player wants to quit the game
            if event.type == pygame.QUIT:
                # quit the game
                pygame.quit()
                sys.exit()
            # to justify the key of the keyboard the player pressed.
            # 4 type are similar so just show one
            elif event.type == pygame.KEYDOWN:
                # to check the key to justify direction that the player want
                if event.key == pygame.K_RIGHT:
                    # do the moving block function and get the function of the return value
                    mflag = gamefunction.moveblock(block, "RIGHT")
                    # check if the game can run and get the value
                    flag = gamefunction.possiblecheck(block)
                    # justify if the game can run or not
                    if flag:
                        # to see if the game actual move
                        if mflag:
                            # generate the new block
                            gamefunction.gengetatenewblock(block)
                            # update the image of the block
                            for i in range(4):
                                for j in range(4):
                                    block[i][j].blockupdate()
                        # update the window
                        pygame.display.flip()
                        continue
                    else:
                        # show the game over message box and then exit the program
                        print("Game over")
                        show_warning("Game over")
                        pygame.quit()
                        sys.exit()
                elif event.key == pygame.K_LEFT:
                    mflag = gamefunction.moveblock(block, "LEFT")
                    flag = gamefunction.possiblecheck(block)
                    if flag:
                        if mflag:
                            gamefunction.gengetatenewblock(block)
                            for i in range(4):
                                for j in range(4):
                                    block[i][j].blockupdate()
                        pygame.display.flip()
                        continue
                    else:
                        print("Game over")
                        show_warning("Game over")
                        pygame.quit()
                        sys.exit()
                elif event.key == pygame.K_DOWN:
                    mflag = gamefunction.moveblock(block, "DOWN")
                    flag = gamefunction.possiblecheck(block)
                    if flag:
                        if mflag:
                            gamefunction.gengetatenewblock(block)
                            for i in range(4):
                                for j in range(4):
                                    block[i][j].blockupdate()
                        pygame.display.flip()
                        continue
                    else:
                        print("Game over")
                        show_warning("Game over")
                        pygame.quit()
                        sys.exit()
                elif event.key == pygame.K_UP:
                    mflag = gamefunction.moveblock(block, "UP")
                    flag = gamefunction.possiblecheck(block)
                    if flag:
                        if mflag:
                            gamefunction.gengetatenewblock(block)
                            for i in range(4):
                                for j in range(4):
                                    block[i][j].blockupdate()
                        pygame.display.flip()
                        continue
                    else:
                        print("Game over")
                        show_warning("Game over")
                        pygame.quit()
                        sys.exit()

            for i in range(4):
                for j in range(4):
                    if block[i][j].value == 2048:
                        show_warning("you win")
                        pygame.quit()
                        sys.exit()
# -*- codeing = utf-8 -*-
# @Time : 2021/11/5 1:57
# @Author : Group 9
# @File : gamefunction.py
# @software : PyCharm
import copy
import random
import sys
from block import Block2048
import pygame


# to initiate the  list of the block table
def initblock(surface):
    # initiate the variable
    block = []
    # create the list and give it default value and set its location
    for i in range(4):
        block.append([Block2048(0, 60, i * 70 + 300, surface), Block2048(0, 130, i * 70 + 300, surface),
                      Block2048(0, 200, i * 70 + 300, surface), Block2048(0, 270, i * 70 + 300, surface)])
    # give the block back
    return block
    pass


# generate the new block by random 2 or 4 in one of the empty block
def gengetatenewblock(block):
    # initiate an empty list
    novaluelist = []

    # justify the block is empty
    for i in range(4):
        for j in range(4):
            if block[i][j].value == 0:
                # if empty, put the index to the list to generate a random number to choose one of them
                novaluelist.append([i, j])
    # if no empty block, just return the original list
    if len(novaluelist) == 0:
        return block
    else:
        # generate the new block and then  return the list
        n = random.randint(0, len(novaluelist) - 1)
        block[novaluelist[n][0]][novaluelist[n][1]].value = random.choice([2, 4])
        return block


# Done white box test passed
# function possiblecheck(block)
# to check if the game can continue run
# return boolen
def possiblecheck(block):
    # initiate the variable of the return value by deafult value False
    finalflag = False
    # to scan the table to see if game can run
    # search it by line
    for indexr in range(4):
        # for the specific row condition
        if indexr == 0:
            # search it by column
            for indexc in range(4):
                # if equal empty, return true
                if block[indexr][indexc].value == 0:
                    block[indexr][indexc].isempty = True
                    finalflag = True
                    # print("1",finalflag)
                    break
                    # for check if the same value 0 , 0 block only need to check 2 nearby block
                if indexc == 0:
                    if block[indexr][indexc].value == block[indexr][indexc + 1].value or block[indexr][indexc].value == \
                            block[indexr + 1][indexc].value:
                        finalflag = True
                        # print("2",finalflag)
                        break
                # 0, 3 block need to check 2
                elif indexc == 3:
                    if block[indexr][indexc].value == block[indexr + 1][indexc].value or block[indexr][indexc].value == \
                            block[indexr][indexc - 1].value:
                        finalflag = True
                        # print("3",finalflag)
                        break
                #  the rest of raw 1 need to check 3 blocks nearby
                elif block[indexr][indexc].value == block[indexr][indexc + 1].value or block[indexr][indexc].value == \
                        block[indexr + 1][indexc].value or block[indexr][indexc].value == block[indexr][
                    indexc - 1].value:
                    finalflag = True
                    # print("4",finalflag)
                    break

        # similar to the  raw 0 but need to reverse it
        elif indexr == 3:
            for indexc in range(4):
                if block[indexr][indexc].value == 0:
                    block[indexr][indexc].isempty = True
                    finalflag = True
                    # print("5",finalflag)
                    break
                if indexc == 0:
                    if block[indexr][indexc].value == block[indexr][indexc + 1].value or block[indexr][indexc].value == \
                            block[indexr - 1][indexc].value:
                        finalflag = True
                        # print("6",finalflag)
                        break
                elif indexc == 3:
                    if block[indexr][indexc].value == block[indexr - 1][indexc].value or block[indexr][indexc].value == \
                            block[indexr][indexc - 1].value:
                        finalflag = True
                        # print("7",finalflag)
                        break
                elif block[indexr][indexc].value == block[indexr][indexc + 1].value or block[indexr][indexc].value == \
                        block[indexr][indexc - 1].value or block[indexr][indexc].value == block[indexr - 1][
                    indexc].value:
                    finalflag = True
                    # print("8",finalflag)
                    break
        else:
            # for raw 1 and 2 , they need check more blocks
            for indexc in range(4):
                if block[indexr][indexc].value == 0:
                    block[indexr][indexc].isempty = True
                    finalflag = True
                    # print("9",finalflag)
                    break

                # in column 0, need to check 3 blocks except the left one
                if indexc == 0:
                    if block[indexr][indexc].value == block[indexr][indexc + 1].value or block[indexr][indexc].value == \
                            block[indexr - 1][indexc].value or block[indexr][indexc].value == block[indexr + 1][
                        indexc].value:
                        finalflag = True
                        # print("10",finalflag)
                        break
                # in column 3, need to check 3 blocks except the right one
                elif indexc == 3:
                    if block[indexr][indexc].value == block[indexr - 1][indexc].value or block[indexr][indexc].value == \
                            block[indexr][indexc - 1].value or block[indexr][indexc].value == block[indexr + 1][
                        indexc].value:
                        finalflag = True
                        # print("11",finalflag)
                        break
                # the rest should check the whole
                elif block[indexr][indexc].value == block[indexr][indexc + 1].value or block[indexr][indexc].value == \
                        block[indexr][indexc - 1].value or block[indexr][indexc].value == block[indexr - 1][
                    indexc].value or block[indexr][indexc].value == block[indexr + 1][indexc].value:
                    finalflag = True
                    # print("12",finalflag)
                    break

    # print("final",finalflag)
    # return the value
    return finalflag


# Done white box test passed
# function moveblock(block)
# to move the block
# input block : list generated before
#               direction string left, right, up ,down to determine the direction player want to move
# return boolen value flag to show if the block actual move
def moveblock(block, direction):
    # initiate the two list and a boolean value for further use
    before = []
    result = []
    flag = False

    # copy the value for back up and check
    for index in range(4):
        result.append([block[index][0].value, block[index][1].value, block[index][2].value, block[index][3].value])

    for index in range(4):
        before.append([result[index][0], result[index][1], result[index][2], result[index][3]])

    # four direction justified by String , to avoid mistake, use .upper to ignore the capital letter error
    if direction.upper() == "LEFT":
        # operate one line by one
        for i in range(4):
            # set the index
            j = 0
            # justify if the operation is correct
            while j <= 3:
                # if the block is empty, move to the next one
                if result[i][j] == 0:
                    j += 1
                # if two nearby block has the same value(the former one must less than 3), combine them and add 2
                elif j < 3 and result[i][j] == result[i][j + 1]:
                    result[i][j] *= 2
                    result[i][j + 1] = 0
                    j += 2
                # if two nearby block has the same value(the former one must less than 2) and an empty block in the
                # middle of them, combine them and move index to 4 to exit the loop
                elif j < 2 and result[i][j + 1] == 0 and result[i][j] == result[i][j + 2]:
                    result[i][j] *= 2
                    result[i][j + 2] = 0
                    j = 4
                # if two same block with 2 empty block separated, combine them and move index to 4 to exit the loop
                elif j == 0 and result[i][j] == result[i][3] and result[i][j + 1] == 0 \
                        and result[i][j + 2] == 0:
                    result[i][j] *= 2
                    result[i][3] = 0
                    j = 4
                else:
                    j += 1

            # reset the index and then create a temper list
            j = 0
            n = []

            # to add non empty block to the list n and empty the block
            while j <= 3:
                if result[i][j] != 0:
                    n.append(result[i][j])
                    result[i][j] = 0
                j += 1
            m = 0
            # return the value of n to the result to make the empty block to the end of the list
            for test in n:
                result[i][m] = test
                m += 1

    # similar to the left operation
    if direction.upper() == "RIGHT":
        for i in range(4):
            j = 3
            while j >= 0:
                if result[i][j] == 0:
                    j -= 1
                elif j > 0 and result[i][j] == result[i][j - 1]:
                    result[i][j] *= 2
                    result[i][j - 1] = 0
                    j -= 2
                elif j > 1 and result[i][j - 1] == 0 and result[i][j] == result[i][j - 2]:
                    result[i][j] *= 2
                    result[i][j - 2] = 0
                    j = -1
                elif j == 3 and result[i][j] == result[i][0] and result[i][j - 1] == 0 \
                        and result[i][j - 2] == 0:
                    result[i][j] *= 2
                    result[i][0] = 0
                    j = -1
                else:
                    j -= 1
            j = 0
            n = []
            while j <= 3:
                if result[i][j] != 0:
                    n.append(result[i][j])
                    result[i][j] = 0
                j += 1
            m = len(n)
            for test in n:
                result[i][3 - m + 1] = test
                m -= 1

    # similar to the left operation, but we should inverse the raw and column index
    if direction.upper() == "UP":
        for j in range(4):
            i = 0
            while i <= 3:
                if result[i][j] == 0:
                    i += 1
                elif i < 3 and result[i][j] == result[i + 1][j]:
                    result[i][j] *= 2
                    result[i + 1][j] = 0
                    i += 2
                elif i < 2 and result[i + 1][j] == 0 and result[i][j] == result[i + 2][j]:
                    result[i][j] *= 2
                    result[i + 2][j] = 0
                    i += 1
                elif i == 0 and result[i][j] == result[3][j] and result[i + 1][j] == 0 \
                        and result[i + 2][j] == 0:
                    result[i][j] *= 2
                    result[3][j] = 0
                    i = 4
                else:
                    i += 1
            i = 0
            n = []
            while i <= 3:
                if result[i][j] != 0:
                    n.append(result[i][j])
                    result[i][j] = 0
                i += 1
            m = 0
            for test in n:
                result[m][j] = test
                m += 1
        pass

    # similar to the up
    if direction.upper() == "DOWN":
        for j in range(4):
            i = 3
            while i >= 0:
                if result[i][j] == 0:
                    i -= 1
                elif i > 0 and result[i][j] == result[i - 1][j]:
                    result[i][j] *= 2
                    result[i - 1][j] = 0
                    i -= 2
                elif i > 1 and result[i - 1][j] == 0 and result[i][j] == result[i - 2][j]:
                    result[i][j] *= 2
                    result[i - 2][j] = 0
                    i -= 1
                elif i == 3 and result[i][j] == result[0][j] and result[i - 1][j] == 0 \
                        and result[i - 2][j] == 0:
                    result[i][j] *= 2
                    result[0][j] = 0
                    i = -1
                else:
                    i -= 1
            i = 0
            n = []
            while i <= 3:
                if result[i][j] != 0:
                    n.append(result[i][j])
                    result[i][j] = 0
                i += 1
            m = len(n)
            for test in n:
                result[3 - m + 1][j] = test
                m -= 1
        pass

    # return the value to the list of the block
    for i in range(4):
        for j in range(4):
            block[i][j].value = result[i][j]
            block[i][j].blockupdate()

    # to check if the block is actual move by compare the block one by one
    for i in range(4):
        if flag:
            break
        else:
            for j in range(4):
                if before[i][j] == result[i][j]:
                    flag = False
                else:
                    flag = True
                    break

    # return the flag
    return flag
